from pathlib import Path
import json, zipfile
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
from scipy.stats import t

W=Path(__file__).resolve().parent
R=W/'ECON521-Project'
P=Path(r'C:\Users\adend\AppData\Local\Packages\OpenAI.Codex_2p2nqsd0c76g0\LocalCache\Roaming\Codex\web\Codex\artifact-sessions\exports\latest\d765bdead367d6a8568420b94372df2c37e1d4eb5a71d593e83f9c771a98f81b')
res=pd.read_csv(R/'results/second_stage_update/model_results.csv')
ars=json.loads((R/'results/second_stage_update/anderson_rubin.json').read_text())
checks=[]
for (league,spec),d in res.groupby(['league','specification']):
    d=d.set_index('model')
    assert set(d.index)=={'OLS','first_stage','reduced_form','2SLS'}
    assert d.n.nunique()==d.home_team_clusters.nunique()==d.date_clusters.nunique()==1
    assert d.full_model_rank.nunique()==1
    assert np.isclose(d.loc['2SLS','coefficient'],d.loc['reduced_form','coefficient']/d.loc['first_stage','coefficient'])
    assert np.isclose(d.loc['first_stage','two_way_clustered_Wald_F'],(d.loc['first_stage','coefficient']/d.loc['first_stage','standard_error'])**2)
    crit=t.ppf(.975,d.t_df.iloc[0])
    assert np.allclose(d.ci_low,d.coefficient-crit*d.standard_error)
    assert np.allclose(d.ci_high,d.coefficient+crit*d.standard_error)
    assert np.allclose(d.p_value,2*t.sf(np.abs(d.coefficient/d.standard_error),d.t_df))
    manifest=pd.read_csv(R/f'results/second_stage_update/{league.lower()}_{spec}_sample_manifest.csv')
    assert len(manifest)==d.n.iloc[0]
    assert not manifest.game_id.duplicated().any()
    assert manifest.home_win.isin([0,1]).all()
    assert manifest.attendance.gt(0).all()
    date=pd.to_datetime(manifest.date_key)
    assert manifest.weekend.eq(date.dt.day_of_week.ge(5).astype(int)).all()
    ar=next(a for a in ars if a['league']==league and a['specification']==spec)
    rho,pi=d.loc['reduced_form','coefficient'],d.loc['first_stage','coefficient']
    cov=np.array(ar['covariance_rf_fs'])
    assert np.isclose(cov[0,0],d.loc['reduced_form','standard_error']**2)
    assert np.isclose(cov[1,1],d.loc['first_stage','standard_error']**2)
    for b in ar['confidence_set']['endpoints']:
        stat=(rho-b*pi)**2/(np.array([1,-b])@cov@np.array([1,-b]))
        assert np.isclose(stat,crit**2)
    assert np.isclose(ar['zero_null_p'],d.loc['reduced_form','p_value'])
    checks.append({'league':league,'spec':spec,'n':int(d.n.iloc[0]),'invariants':'all pass'})

ns={'a':'http://schemas.openxmlformats.org/drawingml/2006/main','p':'http://schemas.openxmlformats.org/presentationml/2006/main','c':'http://schemas.openxmlformats.org/drawingml/2006/chart'}
z=zipfile.ZipFile(P/'research_progress_draft.pptx')
slides=sorted([n for n in z.namelist() if __import__('re').match(r'ppt/slides/slide\d+\.xml$',n)],key=lambda n:int(__import__('re').search(r'(\d+)\.xml',n)[1]))
assert len(slides)==12
texts=[]; tables=[]; chartrefs=[]
for i,n in enumerate(slides,1):
    root=ET.fromstring(z.read(n))
    texts.append({'slide':i,'text':'\n'.join(e.text or '' for e in root.findall('.//a:t',ns))})
    tables.append({'slide':i,'tables':len(root.findall('.//a:tbl',ns))})
    chartrefs.append({'slide':i,'chart_refs':len(root.findall('.//c:chart',ns))})
assert all(next(x for x in tables if x['slide']==s)['tables']>=1 for s in [3,5,6,9])
assert next(x for x in chartrefs if x['slide']==5)['chart_refs']>=1
assert next(x for x in chartrefs if x['slide']==7)['chart_refs']>=1
out={'checks':checks,'slide_count':len(slides),'native_tables':tables,'chart_refs':chartrefs,'slide_text':texts}
(W/'independent_review_checks.json').write_text(json.dumps(out,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in out.items() if k!='slide_text'},indent=2))
