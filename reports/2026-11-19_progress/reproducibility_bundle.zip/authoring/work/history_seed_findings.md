# Research history and seed-paper comparison

Audit basis: local clone of AdenDiaz/ECON521-Project, default branch `main`, commit `51c94a98731180e5be3415892c6846a0590f0250` (2026-11-10). This note owns historical/source comparison only; the main agent owns new estimates and slides.

## Documented progression: completed work versus proposals

| Stage | Evidence | Interpretation |
|---|---|---|
| Initial question and IV proposal | `git show 1b87852:README.md` (2026-10-28), Research Design | Broad initial aspiration covered four leagues. Treatment was fan attendance; proposed outcome home-team win percentage; previous-game closeness proposed as IV. Original README already acknowledged possible direct performance effects. |
| Exploratory cleaning/history | `notebooks/archive/FirstStage_exploratory.ipynb`, 15 cells, especially cells 7-13 | Archive cleans, inspects margins and prior-game histories; explicitly says no close threshold or regression is run. Not evidence of prior second-stage work. Provisional modern-era filter started 1960. |
| Canonical first-stage pipeline | Commit `49a3fff`, then `0f79f57`; `scripts/prepare_data.py`, `scripts/first_stage.py`; current `notebooks/01_first_stage.ipynb` cells 0,4,11 | Cleaning and first-stage estimation completed. `0f79f57` changed current-game analysis from provisional 1960-onward to calendar 2001–2019, aligned with available NFL calibration records; broadened percentile grid. Historical values 1.08/0.07 F in `49a3fff` README are superseded, not directly comparable to current 3.47/1.72. |
| Original closeness fails relevance screen | Current `results/first_stage/report.md`, First-stage findings; `selected_first_stage.csv` | At NFL anchor: conventional joint partial F 3.47 MLB, 1.72 NBA. No conventional joint partial F exceeds 10 across tested grid. Some clustered Wald statistics significant; degenerate-cutoff outliers are not useful instruments. |
| Initial alternative screen | Commit `020b0c7`; `results/instrument_candidates/candidate_screen_report.md` | Cross-league schedule conflicts and NBA pregame weather tested; neither ready as common IV. MLB within-two-hours conflict conventional F 12.67 but home-team-clustered Wald F 5.59; NBA weak. Report's instruction to stop before second stage is historical scope, superseded only by user's explicit new authorization. |
| Expanded exploratory search | Commit `51c94a9`; `expanded_candidate_report.md`; `all_candidate_inventory.csv`; expanded/robustness scripts | Calendar, rest/timing, lagged gates, NBA weather thresholds and MLB weather added. Report explicitly says no reduced form or second stage. Weekend chosen as leading candidate to evaluate for both leagues, not validated. |
| New progress update | Current user instruction | Any OLS outcome model, reduced form, 2SLS, or outcome-sensitivity analysis now produced is new exploratory work; label it so. No evidence of earlier completed stage two exists at inspected commit. |

## Closeness rationale and qualifications

The proposed attendance channel is intuitive: a close recent game may sustain fan interest, excitement and expectations for a competitive next game, altering demand before the next outcome. A separate close-prior-game indicator for each current team is interpretable; absolute margin avoids confusing winning with competitive closeness; mapping margins through a common percentile allows cross-sport scaling. The fan-engagement explanation is a plausible theoretical rationale, not an empirically established mechanism in the repository. The actual implementation uses separate immediately previous home/away team game indicators, not an aggregate season closeness statistic.

Counterevidence: first stages are weak; prior-game closeness can reflect team quality and affect fatigue, morale, confidence, injuries or strategic preparation directly. Temporal precedence is insufficient for exclusion or independence. See current `README.md` Research question/First-stage result; `results/first_stage/report.md`, last paragraph of First-stage findings. The old README at `1b87852` explicitly noted a subsequent-performance channel.

NFL anchor is **margin <=3 points** by project definition, not every football one-possession game. It is 1,103/4,808 =22.94%; MLB cutoff 1 run yields 28.25% actual close share; NBA 5 points yields 27.81%. Discreteness means shares need not equal target. NFL is calibration only, not a completed causal/outcome sample. It covers 2001–2019, missing parts of four seasons (current first-stage report names them), rather than requested 2000–2023. Broader source histories do not equal estimation samples.

## Seed paper: read directly, with exact locators

Source: Scott C. Ganz and Kieran Allsop, *A Mere Fan Effect on Home-Court Advantage*, Journal of Sports Economics 25(1), 30–53; copyright/online 2023, journal volume 2024, DOI 10.1177/15270025231200890. File `references/seed_paper/ganz-allsop-2023-a-mere-fan-effect-on-home-court-advantage.pdf`. Printed page = PDF page +29. All 24 pages extracted and read; key methods/table pages 6,7,12,16 also rendered. Extract at `work/history_assets/seed_paper.txt` is only a convenience; cite original PDF.

| Dimension | Seed paper | ECON521 implementation at inspected commit / implication |
|---|---|---|
| Question | Does presence/crowd size cause NBA home-court advantage, isolating the mere effect of fans? Introduction pp.30–32 (PDF1–3). | Broad cross-sport attendance/home-team result question. Similar motivation; distinct setting and estimand. |
| Main sample | 2020–21 NBA regular season; main regression 808 games, 27 home teams: Table1 p.41 (PDF12). Data pp.34–35 (PDF5–6) removes 25 zero-attendance misreports and excludes Indiana, Miami and Sacramento home games due continued zero reporting after reopening. | MLB/NBA calendar 2001–2019 current-game first stages; positive usable attendance and prior-history requirements, with regular/playoff mixed in original sample. NFL calibration; NHL excluded. New stage-two restrictions must be documented separately. |
| Attendance measure/support | Reported fan count from basketball-reference/official summaries, scaled by 1,000 for regressions; zero attendance is substantively important. Largest crowd 8,359; most arenas well below capacity: pp.33,35,38,44–45 (PDF4,6,9,15–16). | Recorded/cleaned attendance counts; current pipeline excludes nonpositive attendance, NBA implausible below100/above100,000. Paid versus turnstile count not independently verified; call recorded attendance. Typical pre-pandemic crowds differ from sparse-arena support. |
| Outcome | Home minus away **point margin**, not win percentage; foul margin supplemental: equation p.35, Table1 p.41 (PDF6,12). | Planned current-game home-team result, `home_win` in processed data. New LPM 2SLS coefficient should be percentage-point win probability per1,000; cannot compare its numeric coefficient with seed points per1,000. Season win-rate language is aggregate motivation, not literal game outcome coding. |
| Instrument/identification | Maximum permitted attendance (fan capacity restriction), based on advance news reports, instrumenting reported attendance; policy limits vary within teams and across arenas. Data pp.35–36 (PDF6–7); rationale pp.31–32,36–37 (PDF2–3,7–8). | Historical previous-game-closeness IV, now weekend scheduling as working candidate. No capacity policy series implemented. Weekend fan availability is not the seed quasi-experiment; exclusion concerns are different. |
| Controls | Home-team FE, away-team FE, month FE, home/away win percentages over prior10 games and local preceding2-week COVID case rates. Equation pp.35–36 (PDF6–7), Table1 p.41 (PDF12). | Original closeness first stage has home/away/season/game-type/weekday/month FE. Strong weekend robustness has home- and away-team-by-season FE, game type/month/hour, rest days, prior wins and signed margins; omits weekday FE to preserve weekend. New model inherits available controls, not COVID policy controls. |
| Main estimand/result | Linear IV response to capacity-induced attendance at low crowds: +1.742 home-margin **points per1,000 fans**, robust SE0.694, N808; Table1 col2 p.41 (PDF12). Authors explore nonlinearity with categorical capacities, pp.42–44 (PDF13–15). | New weekend 2SLS is an exploratory linear response to scheduling-related attendance conditional on validity. It need not identify same effect/population or an overall attendance average treatment effect. With heterogeneous effects, avoid unqualified 'LATE' for a continuous treatment without extra assumptions. |
| Inference | Table1 calls SEs robust; it does not label them home-team/date clustered. Table2 reports F1111.41; do not call it project-style two-way Wald F without validation. p.41 (PDF12). | Project reports classical partial F alongside clustered Wald F; distinction must remain explicit. |
| External validity | Authors explicitly warn not to extrapolate +1.74 from nearly empty arenas to near-capacity arenas and note pandemic context limitations: pp.44–45 (PDF15–16). All-season supplement, Table4 p.43 (PDF14), IV .920 (SE .620), N8,171, statistically imprecise. | The project investigates a substantively different attendance support. This is a reason for the extension and a reason not to treat seed effect as an expected project coefficient. |

Seed's own residual caveats matter: p.34 (PDF5) admits unobserved local pandemic intensity cannot entirely be ruled out. The paper argues relevance and exclusion, but this does not establish either assumption for closeness/weekend. Maximum capacity is measured imperfectly because some reported crowds exceed announced caps (p.35/PDF6). The clean-data stage-two result is similar to uncorrected appendix Table7, p.53 (PDF24):1.651 (SE .719), N923/30 teams. Use seed as motivation and design contrast, not external certification.

Small internal seed discrepancies: equation p.35 includes lagged home-arena point margin, but Table1 p.41 does not display its row; cite it as an equation term rather than claim a confirmed Table1 control. Text pp.35–36 says COVID cases per100,000, tables label per1,000. Avoid reproducing that scaling in the deck. Discussion p.44 refers to1.74 as Table1 col1 although it is col2; authoritative coefficient location is Table1 col2. These do not change the requested main comparison.

## Material repository discrepancies to retain in research notes

1. Earlier `49a3fff` main sample was1960 onward and used a narrower5–95% grid; current `0f79f57` onward is2001–2019 and expanded grid. Use current outputs for slides, label history if mentioned.
2. Current README says 'paid/recorded'; underlying variable is recorded attendance. Payment/turnstile distinction is not established by this audit.
3. `expanded_candidate_report.md` labels one row 'Prior-season average attendance', but `scripts/expanded_iv_screen.py` lines60–62 and candidate definition line338 compute **season-to-date mean of prior home-game attendance**, not previous season's mean. Use actual definition.
4. Current cleaning summaries' attendance-quality counts include excluded game types, while data-coverage valid-attendance totals refer to cleaned games; do not treat those totals as inconsistent sample counts without matching population.
5. Broad aspiration originally four leagues; actual estimation at snapshot MLB/NBA only. User's current scope NBA/NFL/MLB should be distinguished from archived NHL aspiration.
6. No project-assigned Table1–4/Figure1–3 scheme found in README, current reports, scripts, notebook markdown, or archived notebook source. Native HTML/dataframe 'table' outputs in notebook are not numbered paper exhibits. New coherent exhibit numbering is appropriate; keep seed's Table/Figure numbers clearly identified as seed-only.

## Suggested concise seed slide

Title: 'A different attendance margin from the seed paper'

Seed: NBA2020–21;808 games/27 home teams; capacity limits instrument recorded attendance; home point margin; first8,359 fans.
Project: MLB/NBA2001–2019; weekend working IV; game-level home-win probability; typical pre-pandemic crowds.

Takeaway: shared reverse-causality problem, different instrument, outcome and crowd support. Seed's1.742 points/1,000 is not comparable to project percentage points/1,000. Cite on slide: 'Ganz & Allsop, pp.35–36,41,44–45 (PDF6–7,12,15–16); repository README and weekend robustness script.'

## Suggested narrative labels

- Completed before update: clean samples, weak closeness grid, exploratory alternatives and weekend first-stage robustness.
- Newly estimated in this update: game-outcome OLS/reduced form/2SLS and sensitivity.
- Remaining: exclusion/independence argument, richer rest/travel/timing checks, confirmatory design or external shock.
