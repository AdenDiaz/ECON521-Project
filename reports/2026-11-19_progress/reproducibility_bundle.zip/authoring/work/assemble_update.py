"""Assemble verified numerical exhibits, research notes and scientific figures.

Run after scripts/second_stage_update/weekend_iv.py. Paths are relative to this
project workspace, not the user's home. No historical estimates are rerun.
"""
from pathlib import Path
import json, math, re, shutil, html
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT/'work/ECON521-Project'
OUT=ROOT/'outputs'
NEW=REPO/'results/second_stage_update'
ASSETS=ROOT/'work/report_assets'
ASSETS.mkdir(exist_ok=True)
OUT.mkdir(exist_ok=True)
hist=json.loads((ROOT/'work/exhibit_data.json').read_text(encoding='utf-8'))
res=pd.read_csv(NEW/'model_results.csv')
audit=json.loads((NEW/'data_audit.json').read_text(encoding='utf-8'))
ars=json.loads((NEW/'anderson_rubin.json').read_text(encoding='utf-8'))
franchise=pd.read_csv(NEW/'franchise_cluster_sensitivity.csv')

def row(league,spec,model):
    r=res[(res.league==league)&(res.specification==spec)&(res.model==model)]
    assert len(r)==1,(league,spec,model)
    return r.iloc[0].to_dict()
def num(v,k=2):return f'{v:,.{k}f}'
def ci(r,scale=100,k=2):return f"{num(scale*r['coefficient'],k)} [{num(scale*r['ci_low'],k)}, {num(scale*r['ci_high'],k)}]"
def simplify(r):
    v=dict(coef=r['coefficient'],ci_low=r['ci_low'],ci_high=r['ci_high'],se=r['standard_error'],wald_f=r['two_way_clustered_Wald_F'],classical_f=r['classical_partial_F'])
    return {k:(float(x) if np.isfinite(x) else None) for k,x in v.items()}
def arrow(league,spec='main'):
    return next(a for a in ars if a['league']==league and a['specification']==spec)
def artext(league,spec='main'):
    a=arrow(league,spec)['confidence_set']
    if a['type']=='bounded_interval':return f"[{100*a['endpoints'][0]:.2f}, {100*a['endpoints'][1]:.2f}]"
    return a['type']+' '+str(a['endpoints'])

data={'historical':{'curves':{}},'main':{}}
for league in ['MLB','NBA']:
    ar=next(a for a in audit['leagues'] if a['league']==league)
    r=row(league,'main','2SLS')
    common=dict(n=int(r['n']),home_clusters=int(r['home_team_clusters']),date_clusters=int(r['date_clusters']),attendance_mean=ar['main_attendance_mean'],home_win_mean=ar['main_home_win_mean'])
    for key,model in [('ols','OLS'),('fs','first_stage'),('rf','reduced_form'),('iv','2SLS')]:common[key]=simplify(row(league,'main',model))
    data['main'][league]=common
    grid=[a for a in hist['closeness_grid_integer_percentiles'] if a['league']==league]
    data['historical']['curves'][league]={'x':[100*a['percentile'] for a in grid],'y':[a['joint_F_classical'] for a in grid]}
data['main']['stage1Chart']={'categories':['Historical team-season','New main: year-month','New sensitivity: week']}
for league in ['MLB','NBA']:
    old=next(a for a in hist['weekend_team_season'] if a['league']==league)
    data['main']['stage1Chart'][league]=[old['coefficient_attendance']/1000,row(league,'main','first_stage')['coefficient'],row(league,'calendar_week','first_stage')['coefficient']]
forestrows=[(l,s) for l in ['MLB','NBA'] for s in ['main','calendar_week']]
vals=[100*row(l,s,'2SLS')[v] for l,s in forestrows for v in ['ci_low','ci_high']]
lo=math.floor((min(vals)-.2)*2)/2;hi=math.ceil((max(vals)+.2)*2)/2
step=.5 if hi-lo<=4 else 1 if hi-lo<=8 else 2
series=[{'name':'Zero','xValues':[0,0],'values':[.5,4.5],'line':{'fill':'#A7B2BC','width':1,'style':'dashed'},'marker':{'symbol':'none'}}]
for idx,(league,spec) in enumerate(forestrows):
    r=row(league,spec,'2SLS');y=4-idx;color='#246C91' if league=='MLB' else '#287B70'
    label=league+(': main' if spec=='main' else ': week FE')
    series.append({'name':label+' 95% CI','xValues':[100*r['ci_low'],100*r['ci_high']],'values':[y,y],'line':{'fill':color,'width':3},'marker':{'symbol':'none'}})
    series.append({'name':label,'xValues':[100*r['coefficient']],'values':[y],'line':{'fill':'none','width':0},'marker':{'symbol':'circle' if spec=='main' else 'diamond','size':9,'fill':color},'dataLabels':{'showSeriesName':True,'position':'top','textStyle':{'fontSize':19,'typeface':'Arial','fill':color}}})
data['main']['forest']={'series':series,'min':lo,'max':hi,'step':step}
data['main']['ivSummary']='\n'.join(f"{l}: {100*row(l,'main','2SLS')['coefficient']:.2f} / {100*row(l,'calendar_week','2SLS')['coefficient']:.2f} pp" for l in ['MLB','NBA'])
data['main']['arSummary']=f"95% Anderson–Rubin confidence sets (pp / 1,000): MLB {artext('MLB')}; NBA {artext('NBA')}. Weak-IV robust conditional on validity; few-cluster uncertainty remains."
data['main']['conclusion']='MLB: +0.28 pp per 1,000. NBA: −1.09 pp, imprecise and sensitive to timing controls. Both are conditional on IV assumptions.'
(ROOT/'work/deck_data.json').write_text(json.dumps(data,indent=2,allow_nan=True),encoding='utf-8')

# Scientific figures for the report, independent of editable native slide charts.
plt.rcParams.update({'font.family':'Arial','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold'})
fig,axs=plt.subplots(1,2,figsize=(10.5,3.4),sharey=True)
for ax,l,c in zip(axs,['MLB','NBA'],['#246C91','#287B70']):
    z=data['historical']['curves'][l];ax.plot(z['x'],z['y'],color=c,lw=2)
    ax.axhline(10,color='#AA523C',ls='--',lw=1);ax.axvline(22.94093178,color='gray',ls=':',lw=1)
    ax.set(title=l,xlabel='Target closeness percentile (%)',ylim=(0,11),xlim=(0,100));ax.grid(axis='y',alpha=.15)
axs[0].set_ylabel('Classical joint partial F');fig.tight_layout();fig.savefig(ASSETS/'closeness_grid.png',dpi=180);plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(10.5,4.2))
for ax,l,c in zip(axs,['MLB','NBA'],['#246C91','#287B70']):
    specs=['main','pooled_month','calendar_week','recorded_hour']+(['no_doubleheaders'] if l=='MLB' else [])
    names=['Main: year-month','Pooled month','Calendar week','Recorded-hour control']+(['Omit doubleheaders'] if l=='MLB' else [])
    rr=[row(l,s,'first_stage') for s in specs];y=np.arange(len(rr))
    ax.errorbar([a['coefficient'] for a in rr],y,xerr=[[a['coefficient']-a['ci_low'] for a in rr],[a['ci_high']-a['coefficient'] for a in rr]],fmt='o',color=c,capsize=3)
    ax.set(yticks=y,yticklabels=names,title=l,xlabel='Weekend attendance change (1,000)');ax.invert_yaxis();ax.grid(axis='x',alpha=.15)
fig.tight_layout();fig.savefig(ASSETS/'weekend_first_stages.png',dpi=180);plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(10.5,4.2))
for ax,l,c in zip(axs,['MLB','NBA'],['#246C91','#287B70']):
    specs=['main','pooled_month','calendar_week','recorded_hour']+(['no_doubleheaders'] if l=='MLB' else [])
    rr=[row(l,s,'2SLS') for s in specs];names=['Main: year-month','Pooled month','Calendar week','Recorded-hour control']+(['Omit doubleheaders'] if l=='MLB' else [])
    y=np.arange(len(rr));ax.errorbar([100*a['coefficient'] for a in rr],y,xerr=[[100*(a['coefficient']-a['ci_low']) for a in rr],[100*(a['ci_high']-a['coefficient']) for a in rr]],fmt='o',color=c,capsize=3)
    ax.axvline(0,color='gray',ls='--',lw=1);ax.set(yticks=y,yticklabels=names,title=l,xlabel='Home-win percentage points / 1,000');ax.invert_yaxis();ax.grid(axis='x',alpha=.15)
fig.tight_layout();fig.savefig(ASSETS/'outcome_sensitivities.png',dpi=180);plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(10.5,3.5))
for ax,l,c in zip(axs,['MLB','NBA'],['#246C91','#287B70']):
    mf=pd.read_csv(NEW/f'{l.lower()}_main_sample_manifest.csv')
    bins=np.linspace(0,65000 if l=='MLB' else 40000,35)
    ax.hist(mf.attendance,bins=bins,color=c,alpha=.85);ax.set(title=l,xlabel='Recorded attendance',ylabel='Games');ax.grid(axis='y',alpha=.15)
fig.tight_layout();fig.savefig(ASSETS/'attendance_support.png',dpi=180);plt.close(fig)

history=(ROOT/'work/history_seed_findings.md').read_text(encoding='utf-8')
evidence=(ROOT/'work/evidence_audit.md').read_text(encoding='utf-8')
seed=history.split('## Seed paper: read directly, with exact locators')[1].split('## Material repository discrepancies')[0]
seed=seed.replace('All 24 pages extracted and read; key methods/table pages 6,7,12,16 also rendered. Extract at `work/history_assets/seed_paper.txt` is only a convenience; cite original PDF.','All 24 PDF pages were read; key methods and result pages were also rendered.')
progress=history.split('## Documented progression: completed work versus proposals')[1].split('## Seed paper:')[0]
progress=progress.replace("Current user instruction",'November 19, 2026 extension').replace("user's explicit new authorization",'the authorized new extension')
inventory=evidence.split('## Complete preserved inventory and search dimensions')[1].split('## Material discrepancies')[0]
discrep=evidence.split('## Material discrepancies to disclose')[1].split('This audit has not')[0]
discrep=discrep.replace('Agent C', 'The new analysis')
plan=(REPO/'scripts/second_stage_update/analysis_plan.md').read_text(encoding='utf-8')
plan=plan.replace('Parent agent approved this model','The specification was approved').replace('your source audit','the source audit')
plan=plan.replace('- Main controls: home-team-by-season and away-team-by-season FE, calendar-year-by-month FE, categorical recorded start hour, rest days for each side, immediately previous same-season game result and signed margin for each side.', '- Final main controls: home-team-by-season and away-team-by-season FE, calendar-year-by-month FE, rest days for each side, immediately previous same-season game result and signed margin for each side. Recorded start hour is omitted from main and added only in sensitivity; see the source-audit amendment below.')
plan=plan.replace('season-week FE','calendar-week FE').replace('parent source audit','source audit')
plan_report='''The initial model plan was recorded before outcome regressions. It extended the repository's strongest weekend specification with separate regular-season MLB/NBA models and year-month common shocks. The final main specification omits recorded hour because scheduled-versus-realized timing is not established. Planned sensitivities use pooled month, calendar-week effects, recorded hour, and MLB doubleheader omission. All four equations retain common observations and exogenous controls within a specification; no instrument or model is chosen by outcome significance.

The source-audit amendment occurred after an initial unattended execution had fit two MLB models and emitted progress messages only, before either analyst inspected coefficients, standard errors or significance. The decision to omit hour from main was based on measurement timing, not results. The original plan and amendment are preserved in `analysis_plan.md`; the separate franchise-cluster inference audit was added after examining source IDs and preserves the primary specification and estimates.
'''
md=f'''# ECON521 research progress update

Aden Diaz | November 19, 2026

## Status and provenance

The project asks whether fan attendance affects home-team outcomes. This update documents the progression from previous-game closeness to the weekend working instrument and adds preliminary game-level OLS, reduced-form and 2SLS models for MLB and NBA. All new IV interpretations are conditional on relevance, independence and exclusion. Weekend scheduling may directly affect play, so the results do not establish a causal attendance effect.

GitHub plugin access was verified; the default branch was `main`, at `51c94a98731180e5be3415892c6846a0590f0250` (November 10, 2026). A local clone matched that commit. Historical files, raw data and cached weather were preserved. The historical instrument search was audited from saved outputs, not rerun. The update adds only new scripts/results. Nothing was committed, pushed or submitted.

The broader current research scope is NBA, NFL and MLB. At the source snapshot only MLB and NBA have estimation samples. NFL provides the closeness calibration reference, with incomplete season coverage. NHL appeared in the initial aspiration but is excluded for lack of suitable data. NFL is not presented as a completed causal analysis.

## Research progression
{progress}

## Seed-paper comparison
{seed}

## Exhibit numbering and source hierarchy

No project-assigned Table 1–4 or Figure 1–3 numbering was found in the README, reports, scripts, guided notebook or archive source. This update assigns Table 1 to samples, Table 2 to closeness, Table 3 to alternatives, Table 4 to new outcome models, Figure 1 to closeness thresholds, Figure 2 to weekend first stages and Figure 3 to new IV estimates. Seed exhibit numbers refer only to that paper. Source-specific CSVs take precedence over prose and inventory labels. The accompanying source map links every slide to files or paper pages.

## Data audit and new sample construction

Each canonical game ID and source-row key was checked for uniqueness. Raw joins are validated one-to-one, with exact ID agreement. Previous games are checked against canonical histories for team identity, season and chronology; same-day MLB lags require validated game order. Histories were constructed before the current attendance filter. No raw records were edited.

Recorded attendance is a count of persons, divided by 1,000 for estimation. A common paid-versus-present definition and capacity normalization are not established. The current home-win variable in historical processed data codes ties 0.5. The new dependent variable is strictly binary: 1 if home score exceeds away score and 0 if below; ties are excluded. NBA tied-score records are anomalies because NBA games cannot finish tied; their direct lag controls are also excluded. MLB valid prior ties remain 0.5 in the pregame prior-result control. These choices change the outcome sample, not the historical first-stage files.

| Sample measure | MLB | NBA |
|---|---:|---:|
'''
for title,key in [('Cleaned current games, 2001–2019','clean_rows_2001_2019'),('Missing attendance in that window','window_missing_attendance'),('Historical first-stage sample','first_stage_rows'),('Regular-season historical sample','regular_first_stage_rows'),('Current regular tied scores excluded','regular_tied_scores_excluded'),('Further decisive rows missing lag controls','regular_decisive_rows_missing_lag_controls_excluded'),('New main N','main_n'),('Missing recorded start hour','main_missing_start_hour'),('Identified doubleheader rows in main','main_doubleheader_rows'),('Weekend games in main','main_weekend_n'),('Weekday games in main','main_weekday_n')]:
    aa={a['league']:a for a in audit['leagues']};md+=f"| {title} | {aa['MLB'][key]:,} | {aa['NBA'][key]:,} |\n"
md+='\n'
for l in ['MLB','NBA']:
    a=next(a for a in audit['leagues'] if a['league']==l);r=row(l,'main','2SLS')
    md+=f"{l}: main dates {a['main_date_min']} through {a['main_date_max']}; mean attendance {a['main_attendance_mean']:,.1f} (SD {a['main_attendance_sd']:,.1f}); home-win share {100*a['main_home_win_mean']:.2f}%; {int(r['home_team_clusters'])} home-team clusters and {int(r['date_clusters']):,} date clusters.\n\n"
md+='''The weekend indicator is Saturday or Sunday on the stored source-calendar date; Friday is excluded. NBA source timezone is undocumented, so no timezone correction was invented. MLB recorded start time comes from a validated raw join; NBA hour comes from the raw timestamp. Neither establishes scheduled versus realized time. The main model therefore omits current start hour. A recorded-hour sensitivity retains the strongest historical specification's timing proxy, with that limitation explicit. Rest is max(calendar-date gap minus 1, 0), computed using the immediately prior same-season game; it does not measure travel, time-zone changes or fatigue directly. See `data_audit.json` for exact exclusions and tied record IDs.

![Attendance support](report_assets/attendance_support.png)

Figure R1. New main-sample attendance distributions. This attendance support differs substantially from the seed paper's sparse 2020–21 arenas. Distributions are descriptive, not causal evidence.

## Original closeness evidence

Table 2 uses the NFL <=3-point anchor: 1,103 / 4,808 = 22.94%. The empirical inverse-CDF cutoff is 1 MLB run and 5 NBA points, with achieved close shares of 28.25% and 27.81%. Separate previous-game close indicators for the current home and away teams enter jointly. Controls are home-team, away-team, season, game-type, weekday and month effects; inference clusters by current home team.

| NFL-anchor statistic | MLB | NBA |
|---|---:|---:|
| Games | 46,300 | 24,264 |
| Home prior-close gate coefficient (cluster SE), fans | 102.57 (104.47) | 20.31 (22.80) |
| Away prior-close gate coefficient (cluster SE), fans | 104.48 (93.81) | 49.00 (26.06) |
| Classical joint partial F | 3.47 | 1.72 |
| Home-team-clustered joint Wald F | 4.90 | 2.95 |
| Home-team-clustered joint p | .0141 | .0680 |

![Closeness grid](report_assets/closeness_grid.png)

Figure 1. Classical joint partial F for integer target percentiles 1–99. The dotted line marks the NFL anchor and dashed line the conventional F=10 screen. The full 362-row saved grid also includes margin-cutoff transitions and the exact anchor. Some rows repeat identical models. Across all cutoffs the maximum classical F is 3.47 MLB and 4.17 NBA; the NBA maximum occurs at a zero-point, almost-empty close category, outside 1–99%. The largest clustered spikes are near-degenerate endpoint artifacts: NBA Wald F184.99 vs classical F4.17 with 0.00813% close; MLB Wald F21.39 vs classical F0.40 with 99.99786% close and only one active IV. These do not provide useful relevance evidence.

## Alternative search and complete candidate inventory
'''+inventory
md+='''
The complete original `all_candidate_inventory.csv` is included unchanged in the analysis bundle, alongside the underlying historical result CSVs. It records 772 candidate/specification rows, not 772 independent instruments. The inventory contains 761 estimated rows, 10 absorbed rows and 1 not estimable row. Three unlabeled rows belong to NBA initial weather. Adjacent closeness percentiles and duplicate timing definitions further reduce the number of distinct ideas. Multiple definitions, windows and thresholds were explored, so nominal p-values and rankings are exploratory.

Table 3 in the slides summarizes weekend, home opener, holiday, prior gates, MLB dome cold, NBA weather and metro conflict. Their models and samples differ. Weekend/holiday use team-season effects, opener/prior gates and weather use exact date where identified; metro baseline uses home-team-only clustering. Recorded outdoor temperature is also predictive (MLB below55F Wald F35.52) but can directly alter baseball conditions and is a relevance benchmark rather than a credible IV. Earlier fixed-roof-only concerns do not contradict the later broader dome-marked screen: their sites and definitions differ.

Weekend has an interpretable fan-availability channel and strong relevance in both leagues. Home openers have ceremonies, motivation and roster-selection pathways; prior attendance proxies persistent demand/quality; holiday scheduling is selected. The MLB dome-weather result has only 10 team clusters and many searched thresholds, and outdoor conditions may still affect team travel. NBA weather and cross-league conflicts did not clear the relevant clustered F=10 screen. None of these first-stage comparisons proves exclusion or independence.

## New preliminary analysis: decisions and inference
'''+plan_report
md+='''
The final main equation is a linear probability model with endogenous attendance/1,000. Both stages include the same home-team×season and away-team×season effects, calendar-year×month effects, home/away rest days, previous-game result and signed score margin. Regular-season restrictions make game-type effects constant, so they are not added as redundant regressors. The OLS benchmark, first stage, reduced form and IV use identical rows and controls within each specification. In the exactly identified model the IV coefficient equals reduced-form divided by first-stage coefficient, an identity checked in code.

The two-way cluster sandwich uses projected-regressor scores multiplied by **structural** IV residuals. It never treats fitted attendance as an observed regressor for naive OLS inference. The covariance applies inclusion–exclusion for home-team and date clusters, with per-component CR1 correction G/(G−1) × (N−1)/(N−K). K includes the exact bipartite rank of home/away team-season effects, residualized exogenous-control rank and one treatment/instrument coefficient. Confidence intervals use t with min(home-team,date cluster counts)−1 degrees of freedom. Historical absorbed-FE routines did not count absorbed effects in their correction; new precision is not silently copied from those routines. The small number of team clusters and dependence through away teams remain limitations; no small-cluster bootstrap is claimed.

Classical partial F is the single excluded-instrument t squared using homoskedastic residual variance and full residual degrees of freedom. The two-way clustered Wald F is the clustered coefficient t squared. Neither is a Kleibergen–Paap or effective-F statistic and neither is a validity test. Single-instrument Anderson–Rubin confidence sets invert clustered tests of Y−bA on Z and the common controls. These protect against weak relevance conditional on a valid instrument, using the same approximate few-cluster reference distribution; they do not protect against exclusion failure.

Exact-date effects and a complete weekday set absorb weekend. Calendar-year×month effects preserve within-month identifying variation but leave daily shocks and day-specific direct effects uncontrolled. Calendar-week sensitivity probes finer common timing, still without date saturation. Weekend relevance cannot settle schedule selection.

## New estimates

Table 4. Main model coefficients [95% clustered t interval]. Outcome coefficients are percentage points; attendance first stage is in thousands of attendees. OLS and IV outcome coefficients are per 1,000 additional recorded attendees.

| Model / diagnostic | MLB | NBA |
|---|---:|---:|
'''
for title,model,scale in [('OLS home-win effect','OLS',100),('Weekend attendance first stage','first_stage',1),('Weekend reduced form, pp','reduced_form',100),('2SLS home-win effect','2SLS',100)]:md+=f"| {title} | {ci(row('MLB','main',model),scale)} | {ci(row('NBA','main',model),scale)} |\n"
md+=f"| Classical partial F | {row('MLB','main','first_stage')['classical_partial_F']:.2f} | {row('NBA','main','first_stage')['classical_partial_F']:.2f} |\n"
md+=f"| Two-way clustered Wald F | {row('MLB','main','first_stage')['two_way_clustered_Wald_F']:.2f} | {row('NBA','main','first_stage')['two_way_clustered_Wald_F']:.2f} |\n"
md+=f"| Anderson–Rubin 95% set, pp/1,000 | {artext('MLB')} | {artext('NBA')} |\n\n"
md+='''These are newly estimated exploratory coefficients. An attendance coefficient of 0.01 in probability units means +1 percentage point per 1,000 attendees; it is not a 1% relative change, a season win-rate regression, or a score-margin effect. OLS adjusts measured covariates but remains vulnerable to endogenous fan demand. The IV coefficient is a scheduling-induced linear response only under the identifying assumptions, not a demonstrated population-average causal effect. No specification was selected by outcome significance.

![Weekend first stages](report_assets/weekend_first_stages.png)

Figure 2 / R2. Adjusted weekend first stages and 95% intervals in the new sample. Each model also has a same-sample OLS, RF and IV row in `model_results.csv`. Pooled month and calendar-week effects are prespecified alternatives; recorded-hour controls are a caveated comparison; MLB omits identified doubleheader games as a measurement sensitivity.

| IV sensitivity, pp/1,000 [95% CI] | MLB | NBA |
|---|---:|---:|
'''
for spec,title in [('main','Main: year-month'),('pooled_month','Pooled month'),('calendar_week','Calendar week'),('recorded_hour','Recorded-hour control'),('no_doubleheaders','Omit identified doubleheaders')]:
    md+=f"| {title} | {ci(row('MLB',spec,'2SLS'))} | {ci(row('NBA',spec,'2SLS')) if spec!='no_doubleheaders' else 'Not applicable'} |\n"
md+='''
![Outcome sensitivity](report_assets/outcome_sensitivities.png)

Figure 3 / R3. New 2SLS estimates with 95% clustered t intervals. Sensitivities examine substantive calendar, timing and MLB gate-attribution concerns; they are not a search for significance. Interpretation remains conditional even if an interval excludes zero. AR sets for every specification, first-stage partial R-squared and residualized-weekend variance are saved in machine-readable results.

An additional inference audit merges MLB home-team codes FLO/MIA and MON/WAS into stable franchise clusters, reducing 32 source-code clusters to 30 franchises. It preserves all main samples, controls and point estimates. The MLB IV estimate stays +0.2763 pp per 1,000, with alternate SE 0.0839 pp and 95% CI [0.1047, 0.4479], compared with primary [0.1034, 0.4492]. The first-stage clustered Wald F is 181.04. The separate `franchise_cluster_sensitivity.py` reproduces all four alternate equation uncertainties; primary output hashes remain unchanged. This source-ID correction has little effect here and does not resolve few-cluster or exclusion concerns.

## Material discrepancies and reconciliations
'''+discrep
md+='''
Additional new audit decisions: historical samples mixed postseason and regular-season games; main outcome models use only regular season. MLB and NBA are therefore not forced into the old N. NBA source time is not verified local time, so the weekend date convention is maintained transparently. Current-game recorded hour is excluded from main because pregame timing status is not verified. The hour-control plan amendment occurred after an initial unattended implementation had fit two MLB models but before either analyst inspected outcome coefficients; the source-based reason and chronology are preserved in the plan. This is not an outcome-selected change.

## Remaining limitations and next steps

Weekend can affect rest patterns, travel congestion and time zones, broadcast timing, routines, lineups and selected matchups. Available lagged result/margin and rest controls are incomplete proxies. Independence and exclusion therefore remain unproven. Instrument monotonicity is also not established: capacity ceilings, heterogeneous markets or crowd composition could make attendance responses differ. With continuous attendance, do not label the coefficient a universal LATE without extra assumptions. Crowd composition, noise and team support are unmeasured; recorded gates may be sold tickets rather than spectators physically present. Linear probability models summarize local linear changes and may not respect probability bounds in extrapolation.

Source coverage is uneven. NFL has 4,808 score-valid records over 2001–2019, 10 ties, and roughly 89% weekend games; raw outcomes and attendance exist, but a separate NFL scheduling design and support audit are needed. It is not a data-impossibility claim. No NFL causal estimates are reported. The incomplete NFL calibration sample and date-window choice affect cross-league comparability.

Next work should verify source date/time conventions and gate definitions, audit pregame balance for rest/travel/matchup quality, examine home and away dependence with inference appropriate to team networks, and seek externally justified attendance shocks or a confirmatory design. Compare normal-season and sparse-arena effects only after aligning outcome and attendance support. Archive the complete exploratory search rather than treating the leading candidate as validated.

## Reproduction and file guide

The analysis bundle preserves new scripts, all new results and sample manifests, historical result CSVs/reports, this report's editable Markdown, the source map, scientific report figures, the slide source module, exhibit JSON and assembly code. The raw and processed input files remain in the source repository and are SHA-256 indexed in `provenance.json`. Cached weather was not fetched again.

From a fresh clone at the recorded commit, copy the bundle's `scripts/second_stage_update/` into the repository. Create a Python environment and install `scripts/second_stage_update/requirements.lock.txt`; run `python scripts/second_stage_update/weekend_iv.py`. The script writes only `results/second_stage_update/`. See bundle `REPRODUCE.md` for full commands. Rebuilding slides uses `build_slides.mjs` with `deck_data.json` in an Artifact Session or @oai/artifact-tool; editable tables and charts are native slide objects. The submitted PDF is exactly 12 pages including title.

Run `python scripts/second_stage_update/franchise_cluster_sensitivity.py` for the separate stable-franchise inference audit. Main coefficient/covariance validation against `linearmodels IV2SLS` is reproducible with the supplied `validate_main.py` script. The submission PDF preserves the validated slide appearance from high-resolution slide renders; the PPTX retains editable text, tables and charts.

## References

Ganz, Scott C., and Kieran Allsop. 2024 (online 2023). “A Mere Fan Effect on Home-Court Advantage.” Journal of Sports Economics 25(1):30–53. DOI:10.1177/15270025231200890. The local seed PDF was read directly; printed/PDF locators appear in the comparison above.

AdenDiaz/ECON521-Project. `main` at `51c94a98731180e5be3415892c6846a0590f0250`. README, scripts, cleaned data, guided and archived notebooks, Git history, preserved first-stage and candidate CSVs/reports. Numerical authority and slide-level mapping are in `source_map.md`.
'''
(OUT/'research_update.md').write_text(md,encoding='utf-8')

# Readable standalone PDF research report, retaining Markdown as editable source.
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='ReportBody',fontName='Helvetica',fontSize=9.7,leading=13.5,spaceAfter=7))
styles.add(ParagraphStyle(name='ReportSmall',fontName='Helvetica',fontSize=7.7,leading=10))
styles['Heading1'].fontSize=20;styles['Heading1'].leading=24;styles['Heading1'].textColor=colors.HexColor('#172C43')
styles['Heading2'].fontSize=14;styles['Heading2'].leading=18;styles['Heading2'].spaceBefore=14;styles['Heading2'].textColor=colors.HexColor('#246C91')
def para(t,small=False):
    t=html.escape(t)
    t=re.sub(r'`([^`]+)`',r'<font face="Courier">\1</font>',t)
    t=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',t)
    t=re.sub(r'\[([^]]+)\]\([^)]*\)',r'\1',t)
    # Built-in PDF fonts have no multiplication/minus glyph; normalize safely.
    t=t.replace('×',' x ').replace('−','-').replace('→',' to ').replace('≤','&lt;=').replace('π','pi').replace('β','beta').replace('ε','epsilon').replace('γ','gamma').replace('δ','delta')
    return Paragraph(t,styles['ReportSmall' if small else 'ReportBody'])
story=[];lines=md.splitlines();i=0
while i<len(lines):
    line=lines[i].strip()
    if not line:i+=1;continue
    if line.startswith('!['):
        name=re.search(r'\(([^)]+)\)',line)[1].split('/')[-1]
        from PIL import Image as PILImage
        img=ASSETS/name
        iw,ih=PILImage.open(img).size
        story.append(Image(str(img),width=482,height=482*ih/iw));i+=1;continue
    if line.startswith('|'):
        rows=[]
        while i<len(lines) and lines[i].strip().startswith('|'):
            cells=[x.strip() for x in lines[i].strip().strip('|').split('|')]
            if not all(re.fullmatch(r'[:\- ]+',x) for x in cells):rows.append(cells)
            i+=1
        count=max(len(r) for r in rows);rows=[r+['']*(count-len(r)) for r in rows]
        widths=([170]+[(482-170)/(count-1)]*(count-1)) if count in [3,4] else [482/count]*count
        t=Table([[para(c,True) for c in r] for r in rows],colWidths=widths,repeatRows=1,hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E7EDF1')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.7,colors.HexColor('#506172')),('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#D7E0E7')),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]));story.extend([t,Spacer(1,8)]);continue
    if line.startswith('# '):story.append(Paragraph(html.escape(line[2:]),styles['Heading1']));i+=1;continue
    if line.startswith('## '):story.append(Paragraph(html.escape(line[3:]),styles['Heading2']));i+=1;continue
    if line.startswith('### '):story.append(Paragraph(html.escape(line[4:]),styles['Heading3']));i+=1;continue
    block=[line];i+=1
    while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','![')):
        block.append(lines[i].strip());i+=1
    story.append(para(' '.join(block)))
def footer(canvas,doc):
    canvas.setFont('Helvetica',8);canvas.setFillColor(colors.HexColor('#506172'))
    canvas.drawString(56,29,'ECON521 | Research update | Preliminary analysis');canvas.drawRightString(538,29,str(doc.page))
SimpleDocTemplate(str(OUT/'research_update.pdf'),pagesize=(594,792),rightMargin=56,leftMargin=56,topMargin=48,bottomMargin=48,title='ECON521 Research Progress Update',author='Aden Diaz').build(story,onFirstPage=footer,onLaterPages=footer)
print('Assembled deck_data.json, research_update.md/pdf and report figures.')
