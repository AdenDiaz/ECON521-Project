# Evidence and exhibit audit

Repository snapshot: default branch `main`, commit `51c94a98731180e5be3415892c6846a0590f0250`. This audit reads preserved outputs and current code; it does not regenerate the historical search. Machine-readable exhibit rows are in `work/exhibit_data.json`; `work/audit_exhibits.py` reproduces that extract.

## Authority and numbering

- Current `README.md`, `results/first_stage/report.md`, the two candidate reports, the guided `notebooks/01_first_stage.ipynb`, and all relevant source CSVs agree that the snapshot completes data preparation and first-stage screens only. The requested second stage is new work.
- No project-assigned numbered Table 1-3 or Figure 1-2 was found in these current presentation-relevant materials. A coherent new numbering scheme is warranted: Table 1 sample/coverage; Table 2 original closeness first stages; Table 3 candidate comparison; Table 4 new outcome models; Figure 1 closeness grid; Figure 2 weekend robustness; Figure 3 new outcome estimates.
- Source-specific CSVs are authoritative for numerical exhibits. `all_candidate_inventory.csv` is useful as an index, but has missing league labels and misleading percentile formatting (below). The expanded report combines different specifications by candidate; do not imply all rows are from the same controls or sample.

## Table 1: coverage and historical first-stage samples

`results/cleaning/data_coverage.csv` covers the entire cleaned source history, not the 2001-2019 analysis window. `attendance_quality.csv` tabulates **raw** rows before game-type exclusion, explaining its larger valid-attendance totals. The histories are formed before current attendance filtering. Raw attendance should be called recorded attendance/fans, because no ticket-sales validation establishes a common paid-attendance concept.

| Measure | MLB | NBA | NFL |
|---|---:|---:|---:|
| Raw rows | 226,221 | 71,827 | 4,808 |
| Cleaned source rows | 223,655 | 70,025 | 4,808 |
| Full cleaned date years | 1897-2025 | 1946-2025 | 2001-2019 |
| Cleaned current games in 2001-2019 | 46,806 | 24,595 | 4,808 |
| Valid attendance in 2001-2019 | 46,592 | 24,590 | 4,808 |
| Historical first-stage games | 46,300 | 24,264 | calibration only |
| Home-team clusters | 32 | 30 | not estimated |
| Game dates | 3,812 | 3,886 | not estimated |
| Mean recorded attendance (historical sample) | 30,402.97 | 17,575.46 | not needed |
| SD attendance | 10,835.59 | 2,671.21 | not needed |
| Mean tie-adjusted home-result score | .53897 | .59858 | not needed |
| Tied score records | 5 | 2 | not needed |

Do not label the tie-adjusted historical mean a strict home-win indicator: `prepare_data.py` lines 89-92 and 128-131 code ties .5. Agent C should define and document the new strict binary outcome sample. Historical first-stage samples contain regular and postseason games (MLB 45,647 regular and 653 other; NBA 22,699 regular and 1,565 playoff). New estimation may defensibly narrow to regular season; show the resulting **new** sample, not historical N, wherever new estimates appear.

NFL source includes 4,808 score-valid games, of which 1,103 have margin <=3: percentile .2294093178 (22.94%). Four source seasons have fewer than 256 games: 2001:248, 2002:240, 2016:240, 2017:240. This is a source coverage limitation, not an NFL causal analysis.

Sources: `Data/processed/{mlb,nba}_games_clean.csv`, `{mlb,nba}_first_stage_sample.csv`, `results/cleaning/{data_coverage,attendance_quality,history_quality}.csv`, `results/first_stage/nfl_reference.csv`, `nfl_season_coverage.csv`; `scripts/prepare_data.py`; sample descriptions extracted by audit script.

## Table 2 and Figure 1: original closeness

At the NFL-derived 22.94% lower-tail anchor, empirical discrete inverse-CDF cutoffs are MLB <=1 run and NBA <=5 points. The achieved current-game margin-distribution shares are 28.25% and 27.81%, respectively; these differ from home-/away-prior-close shares in the regression samples. Both prior-close indicators enter jointly. Controls: home-team, away-team, season, game-type, weekday and month effects. Inference clustered by current home team.

| Anchor statistic | MLB | NBA |
|---|---:|---:|
| N |46,300|24,264|
| Home prior-close attendance coefficient (fans) |102.57|20.31|
| Home-team-clustered SE |104.47|22.80|
| Away prior-close coefficient (fans) |104.48|49.00|
| Home-team-clustered SE |93.81|26.06|
| **Classical joint partial F** |3.47|1.72|
| **Home-team-clustered joint Wald F** |4.90|2.95|
| Clustered joint p |.0141|.0680|

The full saved grid has 181 percentile rows per league (362 total), corresponding to 23 distinct MLB cutoffs and 59 NBA cutoffs. It includes integer percentiles 1-99, empirical cutoff transitions, and exact NFL anchor; many percentile rows repeat an identical cutoff/model. Max classical joint F across **all** saved rows is MLB3.4697 (1-run cutoff) and NBA4.1711 (0-point cutoff). Within the 1%-99% domain, NBA maximum is only2.6750. Figure 1 should plot classical joint F against target percentile with F=10 guide and anchor reference; include an annotation for out-of-domain degenerate extreme. If plotting all cutoffs against achieved close share, show the near-zero edge and explain it.

Extremes are not strength evidence: NBA cutoff0 classifies just .00813% of underlying game margins as close and gives clustered joint Wald F184.99 vs classical4.17. MLB cutoff22 classifies99.99786% as close and leaves only one active IV; clustered21.39 vs classical.403. They are nearly constant/sparse instruments. The original report's 'largest MLB F at22.94%' is one representative point among repeated percentile rows with the same1-run cutoff, not a unique maximizing percentile. F>10 is a screen only; none establishes exclusion.

Sources: `results/first_stage/{selected_first_stage,selected_thresholds,common_percentile_grid}.csv`, report; `scripts/first_stage.py` `_model_state`, `fit_first_stage`, `threshold_grid`.

## Table 3: candidate search and specification distinctions

Use restrained candidate-family summary; all below are **previously completed first stages**, never prior causal effects. Columns must name the F type. Stronger weekend and holiday rows use team-season effects; opener uses team-season + exact-date effects. Weather rows use separate narrower samples. No suitable comparison pretends the candidate-specific samples or covariates are identical.

| Candidate / chosen historical specification | MLB attendance coefficient; F | NBA attendance coefficient; F | Assessment |
|---|---|---|---|
| Weekend; team-season FE |+5,378.91;131.79|+828.59;64.93|Leading working candidate; rest/travel/timing/selection may directly affect performance|
| Home opener; team-season + exact date |+17,100.52;193.25|+2,011.44;110.66|Strong relevance; ceremonies/motivation/lineups threaten exclusion|
| U.S. federal holiday; team-season FE |+4,235.45;43.34|+470.16;14.20|Selected schedules and routines; exact date absorbs it|
| Five prior home gates mean; team-season + exact date |.2578 coefficient;206.13|.2488 coefficient;188.65|Popularity, persistent quality and demand; coefficient is per prior fan, not binary exposure|
| Same-market other-league start within2h; exact date |−1,025;4.49 (home-team-only Wald F)|+124;1.22 (home-team-only Wald F)|Congestion/team arrival direct paths; weak relevance|
| NBA precipitation>=.5mm in prior12h; team-season + exact date |not NBA exposure|−68.04;8.95|Weak even after threshold search; team travel direct path|
| MLB dome-marked outside cold<13C prior12h; team-season + exact date |−1,922.96;14.86|not estimated|N5,775,10 home-team clusters; thresholds searched; outside travel remains|
| MLB recorded temperature<55F; team-season + exact date |−1,656.55;35.52|not estimated|Outdoor weather directly affects baseball; relevance benchmark|

Except explicitly marked schedule-conflict row, F above = **home-team/date two-way clustered Wald F** (single coefficient t²), not classical F, not Kleibergen-Paap, and not an exclusion test. Historical absorbed-FE covariance routines do not count absorbed FE in their small-sample adjustment; new analysis should state its approach rather than reproducing nominal precision uncritically. Baseline-strong alternatives were mechanically selected for stronger robustness if baseline two-way F>10 (23 rows:13 MLB,10 NBA); stronger-specification selection is still embedded in a broad exploratory search.

Sources: `results/instrument_candidates/team_season_fe_robustness.csv`, `team_season_date_fe_robustness.csv`, `schedule_conflict_first_stage.csv`, `nba_weather_threshold_robustness.csv`, `mlb_dome_weather_robustness.csv`, `mlb_recorded_weather_first_stage.csv`; corresponding scripts. Exact machine-readable rows in exhibit JSON.

## Figure 2: weekend relevance and robustness

Prefer a paired coefficient interval plot for old baseline vs team-season specification (both in fans), or a plot based on Agent C's new consistent sample/specifications. Old baseline coefficients: MLB5,372.75; NBA688.32. Old team-season coefficients: MLB5,378.91; NBA828.59. Baseline two-way Wald Fs117.99 and35.68; stronger Fs131.79 and64.93. Historical samples remain46,300 and24,264. SEs can be recovered exactly as |coefficient|/sqrt(F); use Student t critical values with31/29df as historical routines do. Label the historical values as adjusted associations. Include exact-date row as 'absorbed / not identified' rather than zero. Full weekday indicators likewise absorb Saturday/Sunday weekend.

Raw means are separate descriptive evidence: MLB weekend33,898 vs weekday28,722; NBA18,070 vs17,382. Raw gaps5,176 and689 are **not** adjusted first-stage effects. Avoid mixing them without explicit labels.

Weekend is `game_date.dt.dayofweek.ge(5)` (Saturday/Sunday), using repository source-calendar date, Friday excluded (`scripts/expanded_iv_screen.py`234). Team-season weekend controls omit weekday but retain game-type, month, start-hour, home/away rest days, home/away prior wins and signed prior margins (`team_season_fe_candidate_robustness.py` FORMULAS['weekend']). Home- and away-team x season effects are absorbed. Exact date would remove all identifying weekend variation. Date-level common shocks and day-of-week-specific direct effects cannot be saturated away.

## Complete preserved inventory and search dimensions

`all_candidate_inventory.csv` has772 **candidate/specification rows**, not772 distinct instruments or independent tests. Breakdown:

| Source | Rows |
|---|---:|
| Original closeness grid |362|
| Expanded schedule/calendar/rest/demand grid |50|
| Team-season robustness |23|
| Team-season + exact-date robustness |23|
| NBA initial weather |3|
| NBA weather windows/thresholds |17|
| NBA exact-date weather threshold robustness |80|
| MLB dome weather screen |96|
| MLB dome weather robustness |96|
| MLB recorded weather |14|
| Same-market conflicts |8|

Status:761 estimated,10 exact-date absorbed,1 not estimable. League column:442 MLB,327 NBA,3 missing (these are all initial NBA weather, so corrected interpretation330 NBA). Preserve the original CSV and annotate rather than altering history.

The50-row expanded grid comprises25 per league, with candidates: weekend, Saturday, Sunday, Friday; opening month, late-season month; home opener; federal holiday plus July4(MLB)/Christmas(NBA); last observed home attendance, prior-five-home mean, season-to-date prior-home mean, immediately preceding game's attendance, away team's last home attendance; home/away back-to-back and short-rest; same-market NFL on date and within3/6/9h; afternoon start, late start, MLB second doubleheader game or NBA day game. NBA day_game and afternoon_start are identical in code, so these are duplicated definitions rather than independent discoveries. Weather grids search exposure windows and temperature/precipitation thresholds. Much of the inventory repeats the same instrument with different controls or adjacent percentile definitions; report multiplicity qualitatively and preserve the full indexed CSV externally.

## Material discrepancies to disclose

1. Expanded report labels 'Prior-season average attendance', but variable `mean_prior_season_home_gates` is **season-to-date average of earlier home games within the current season**, `expanded_iv_screen.py`60-62/338. Use the code definition; not a true previous-season average.
2. Inventory's original-closeness definition formats percentile proportions as '0.2294th-percentile' instead of22.94th-percentile (`compile_iv_candidate_inventory.py`126-136). The underlying numeric field is a proportion and source CSV remains correct.
3. Inventory misses league labels on the three initial NBA weather rows; their source file and code identify NBA (`compile_iv_candidate_inventory.py`111-118).
4. Historical home_win includes ties as.5. New binary-win estimates need explicit tie exclusions/recode and must not silently reuse historical sample labels.
5. Historical summary attendance quality counts are raw; coverage counts are cleaned, not inconsistent denominators.
6. Reports call recorded treatment 'paid/recorded', but cross-source measurement comparability is unvalidated. Use recorded attendance, with a measurement limitation.
7. Strong weekend/holiday reports omit exact-date/weekday effects for algebraic reasons; calendar validity remains unresolved. A high F does not remove this limitation.
8. Original policy 'stop before stage2' records previous scope. The authorized extension is new preliminary analysis and should be labeled accordingly.

This audit has not reviewed Agent C's new estimates or final slides yet; those require an independent final review after assembly.
