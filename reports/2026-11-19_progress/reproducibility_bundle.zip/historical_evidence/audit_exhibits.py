from pathlib import Path
import json
import pandas as pd
import numpy as np

WORK = Path(__file__).resolve().parent
REPO = WORK / 'ECON521-Project'
def read(p): return pd.read_csv(REPO/p)
def records(df): return json.loads(df.to_json(orient='records'))

inventory=read('results/instrument_candidates/all_candidate_inventory.csv')
grid=read('results/first_stage/common_percentile_grid.csv')
selected=read('results/first_stage/selected_first_stage.csv')
team=read('results/instrument_candidates/team_season_fe_robustness.csv')
date=read('results/instrument_candidates/team_season_date_fe_robustness.csv')
base=read('results/instrument_candidates/expanded_first_stage_grid.csv')
out={
 'repository': {'branch':'main','commit':'51c94a98731180e5be3415892c6846a0590f0250'},
 'existing_numbering':'No numbered Table 1-3 or Figure 1-2 located in current README, reports, or guided notebook; use a new coherent presentation numbering scheme.',
 'coverage':records(read('results/cleaning/data_coverage.csv')),
 'attendance_quality_raw':records(read('results/cleaning/attendance_quality.csv')),
 'history_quality':records(read('results/cleaning/history_quality.csv')),
 'original_anchor':records(selected),
 'closeness_grid':records(grid),
 'closeness_grid_integer_percentiles':records(grid.loc[grid.percentile.mul(100).round(8).mod(1).eq(0) & grid.percentile.between(.01,.99)]),
 'inventory_counts_by_source': records(inventory.groupby('source_file',dropna=False).size().rename('rows').reset_index()),
 'inventory_counts_by_league': records(inventory.groupby('league',dropna=False).size().rename('rows').reset_index()),
 'inventory_counts_by_status': records(inventory.groupby('status',dropna=False).size().rename('rows').reset_index()),
 'inventory_total':len(inventory),
 'weekend_historical_baseline':records(base.loc[base.candidate.eq('weekend')]),
 'weekend_team_season':records(team.loc[team.candidate.eq('weekend')]),
 'weekend_exact_date_status':records(date.loc[date.candidate.eq('weekend')]),
 'schedule_alternatives_team_season':records(team.loc[team.candidate.isin(['weekend','home_opener','us_federal_holiday'])]),
 'home_opener_exact_date':records(date.loc[date.candidate.eq('home_opener')]),
 'lagged_attendance_exact_date':records(date.loc[date.candidate.str.contains('attendance|gates')]),
 'schedule_conflicts':records(read('results/instrument_candidates/schedule_conflict_first_stage.csv')),
 'nba_initial_weather':records(read('results/instrument_candidates/nba_weather_first_stage.csv')),
 'nba_weather_threshold_top':records(read('results/instrument_candidates/nba_weather_threshold_robustness.csv').nlargest(3,'team_date_two_way_Wald_F')),
 'mlb_dome_weather_top':records(read('results/instrument_candidates/mlb_dome_weather_robustness.csv').nlargest(3,'team_date_two_way_Wald_F')),
 'mlb_recorded_weather_top':records(read('results/instrument_candidates/mlb_recorded_weather_first_stage.csv').nlargest(3,'team_date_two_way_Wald_F')),
 'descriptive_samples':[],
 'grid_summaries':[],
}
for league in ['MLB','NBA']:
 clean=read(f'Data/processed/{league.lower()}_games_clean.csv')
 clean['game_date']=pd.to_datetime(clean.game_date)
 window=clean.loc[clean.game_date.dt.year.between(2001,2019)]
 sample=read(f'Data/processed/{league.lower()}_first_stage_sample.csv')
 sample['game_date']=pd.to_datetime(sample.game_date)
 sample['weekend']=sample.game_date.dt.dayofweek.ge(5)
 d={'league':league,'cleaned_2001_2019_games':len(window),'positive_attendance_2001_2019':int(window.attendance.notna().sum()),
 'historical_first_stage_n':len(sample),'attendance_mean':sample.attendance.mean(),'attendance_sd':sample.attendance.std(),
 'attendance_min':sample.attendance.min(),'attendance_max':sample.attendance.max(),'home_win_nonmissing_n':int(sample.home_win.notna().sum()),
 'home_win_mean_nonmissing':sample.home_win.mean(),'tie_n':int(sample.home_score.eq(sample.away_score).sum()),
 'weekend_share':sample.weekend.mean(),'raw_weekend_attendance_mean':sample.loc[sample.weekend,'attendance'].mean(),
 'raw_weekday_attendance_mean':sample.loc[~sample.weekend,'attendance'].mean(),'date_clusters':sample.game_date.dt.date.nunique(),
 'home_team_clusters':sample.home_team_id.nunique(),'game_type_counts':sample.game_type.value_counts().to_dict()}
 out['descriptive_samples'].append(d)
 g=grid.loc[grid.league.eq(league)]
 out['grid_summaries'].append({'league':league,'grid_rows':len(g),'distinct_cutoffs':int(g.margin_cutoff.nunique()),'max_classical_F':float(g.joint_F_classical.max()),
 'max_classical_row':records(g.nlargest(1,'joint_F_classical'))[0], 'max_clustered_row':records(g.nlargest(1,'joint_F_home_team_cluster'))[0]})

(WORK/'exhibit_data.json').write_text(json.dumps(out,indent=2),encoding='utf8')
print(json.dumps({k:out[k] for k in ['inventory_counts_by_source','inventory_counts_by_league','inventory_counts_by_status','descriptive_samples','grid_summaries']},indent=2))
